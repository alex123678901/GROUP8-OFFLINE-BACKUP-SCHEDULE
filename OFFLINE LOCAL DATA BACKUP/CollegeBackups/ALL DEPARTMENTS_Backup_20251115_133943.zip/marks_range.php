<?php
$marks = 107;

if ($marks < 0 || $marks > 100) {
    echo "Marks Must be between 0 and 100.";
} else {
    if ($marks >= 80) {
        echo "GRADE A";
    } elseif ($marks >= 70) {
        echo "GRADE B";
    } elseif ($marks >= 60) {
        echo "GRADE C";
    } elseif ($marks >= 50) {
        echo "GRADE D";
    } else {
        echo "FAIL";
    }
}
?>